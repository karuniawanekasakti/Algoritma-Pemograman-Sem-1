#QUIZ NO.2
data = input().split()
data_float = list(map(float,data))
jarijari = data_float[0]
tinggi = data_float[1]
phi = 3.14
rumus = (phi * jarijari ** 2 * tinggi) / 3
print(rumus)
