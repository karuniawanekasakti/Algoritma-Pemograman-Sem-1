#Quiz NO.1
x = "1001"
x=list(map(int, x))
b1 = x[3] * 1
b2 = x[2] * 2
b3 = x[1] * 4
b4 = x[0] * 8
jumlah = b1 + b2 + b3 + b4
print(jumlah)




