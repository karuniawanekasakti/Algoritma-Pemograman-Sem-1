m1= input("budi ").split()
m2= input("adi ").split()
m3= input("cici ").split()
m1= list(map(float,m1))
m2= list(map(float,m2))
m3= list(map(float,m3))

rata=(m1[0]+m2[0]+m3[0])/3
ipk =(m1[1]+m2[1]+m3[1])/3
print(rata)
print(ipk)
